from flet import*

def bar_item(page):
    def change_page(e,page):
        # print(page.route)
        # print(e.control.selected_index)
        if e.control.selected_index ==0:
            page.go("/")
            page.update()
        if e.control.selected_index ==1:
            page.go("/login")
            page.update()

    nav_item = NavigationBar(
        # selected_index=1,
        on_change=lambda e:change_page(e,page),
        destinations=[
            NavigationDestination(icon=icons.HOME,label='home'),
            NavigationDestination(icon=icons.LOGIN,label='login'),
        ]
    )
    return nav_item