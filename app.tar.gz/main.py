from flet import*
import flet
from flet_route import Routing,path
from pages.home import Home
from pages.login import Login
from pages.account import Account
from pages.register import Register


def main(page:Page):
    # page.window_width=500
    # page.window_height = 600
    page.theme_mode = 'light'
    # page.window_left = 300
    # page.window_top = 50
    
    app_routes = [
        path(
            url ="/",
            clear = True,
            view = Home().view
        ),
        path(
            url ="/login",
            clear = True,
            view = Login().view
        ),
        path(
            url ="/account/:account_id/:money",
            clear = True,
            view = Account().view
        ),
        path(
            url ="/register",
            clear = True,
            view = Register().view
        ),
    ]
    Routing(
        page=page,
        app_routes = app_routes
    )
    page.go(page.route)
    page.update()

flet.app(target=main,assets_dir="assets",view=WEB_BROWSER)