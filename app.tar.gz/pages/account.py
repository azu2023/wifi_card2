from flet import *
from flet_route import Params,Basket
import requests
import json

class Account(UserControl):
    def __init__(self):
        super().__init__()
        self.page = None

        self.account_text = Text(
                        size=20,
                        weight="w700",
                        text_align="center",
                            )
        self.money_text = Text(
                        size=20,
                        weight="w700",
                        text_align="center",
                            )
        self.card_num = Text(
            value="Wifi-card",
            size=15,
            weight="w500",
            text_align="center",
        )
        self.drop_down = Dropdown(
        # on_change=self.dropdown_changed,
        label="Card",
        helper_text="Choose a card price",
        options=[
            dropdown.Option("100"),
            dropdown.Option("250"),
            dropdown.Option("500"),
            dropdown.Option("1000"),
        ],
        border_radius=10,
        # filled=True,
        border_color=colors.BLACK12,
        # bgcolor=colors.BLACK12,
        focused_bgcolor=colors.BLUE_100,
        width=200,
    )

        self.card = None
        self.account_id = None

    def GradientGenerator(self,start, end):
        ColorGradient = LinearGradient(
            begin=alignment.bottom_left,
            end=alignment.top_right,
            colors=[
                start,
                end,
            ],
        )

        return ColorGradient
    
    def dropdown_changed(self,e):
        card = self.drop_down.value
        data = {
            "account_id":self.account_id,
            "card_price":int(card)
        }
        res = requests.post("https://d184-188-209-230-37.ngrok-free.app/get_code",json=data)

        results = res.content.decode()
        results = json.loads(results)
        # print(results)
        # self.card_num.value ="Wifi-card"
        # self.card_num.update()

        if res.status_code == 201:
            self.card_num.value = results.get("card") 
            self.money_text.value = results.get("money") 
            self.card_num.update()
            self.money_text.update()
            self.page.update()
        if results.get("worning"):
            self.card_num.value = results.get("worning") 
            self.card_num.update()
            self.page.update()
        else:
            return True

    def view(self,page:Page,params:Params,basket:Basket):
        # print(params.get("account_id"),params.get("money"))
        # print(basket)
        self.account_text.value = params.get("account_id")
        self.money_text.value = params.get("money")
        self.account_id = self.account_text.value
        
        self.page = page
        return View(
            controls=[
                Row(
                    alignment='center',
                    controls=[
                        Card(
                            elevation=15,
                            content=Container(
                                # width=400,
                                # height=400,
                                padding=padding.all(20),
                                gradient=self.GradientGenerator(
                                    "#ffffff", "#c6f0f0"
                                ),
                                border_radius=border_radius.all(12),
                                content=Column(
                                    horizontal_alignment="center",
                                    alignment="start",
                                    controls=[
                                    self.account_text,
                                    self.money_text,
                                    Container(padding=padding.only(bottom=10)),
                                    self.drop_down,
                                    Container(padding=padding.only(bottom=10)),
                                    FilledButton(
                                        content=Text(
                                            "Get Code",
                                            weight="w500",
                                            
                                        ),
                                        on_click=self.dropdown_changed,
                                        width=160,
                                        height=40,
                                    ),
                                    Container(padding=padding.only(bottom=10)),
                                    self.card_num,
                                    Container(padding=padding.only(top=60)),
                                    FilledButton(
                                        content=Text(
                                            "Logout",
                                            weight="w500",
                                        ),
                                        width=140,
                                        height=40,
                                        on_click=lambda __: page.go(
                                            "/login"
                                        ),
                                    ),
                                ]
                                )
                        )
                        )
                    ]
                ),
                
            ]
        )
    