from flet import *
from nav_com import bar_item
from flet_route import Params,Basket
import requests
import json

class Home(UserControl):
    def __init__(self):
        super().__init__()
        
    def GradientGenerator(self,start, end):
        ColorGradient = LinearGradient(
            begin=alignment.bottom_left,
            end=alignment.top_right,
            colors=[
                start,
                end,
            ],
        )

        return ColorGradient
    
    def get_home_data(self):
        data = ""
        res = requests.post("https://d184-188-209-230-37.ngrok-free.app/",json=data)

        results = res.content.decode()
        results = json.loads(results)
        return results

    def view(self,page:Page,params:Params,basket:Basket):
       
        return View(
            controls=[
                bar_item(page)
            ]
        )
    