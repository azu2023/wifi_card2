from flet import*
from nav_com import bar_item
from flet_route import Params,Basket
import requests
import json

class Register(UserControl):
    def __init__(self):
        super().__init__()

        self.snack = SnackBar(
        Text("Registration successfull!"),

    )
        
    def GradientGenerator(self,start, end):
        ColorGradient = LinearGradient(
            begin=alignment.bottom_left,
            end=alignment.top_right,
            colors=[
                start,
                end,
            ],
        )
        return ColorGradient
    
    def register_user(self,e,phone,password,page):
        data = {
            "phone":phone,
            "password":password
        }
        res = requests.post("https://d184-188-209-230-37.ngrok-free.app/register",json=data)

        results = res.content.decode()
        results = json.loads(results)
        if res.status_code == 201:
            self.snack.content.value = results.get("OK")
            self.snack.open = True
            page.update()
            page.go("/login")
        else:
            self.snack.content = results.get("error")
            self.snack.open = True
            page.update()
        

    def view(self,page:Page,params:Params,basket:Basket):

        self.phone_text = TextField(
            label="Phone",
            border="underline",
            width=260,
            text_size=14,
        )

        self.password = TextField(
            label="Password",
            border="underline",
            width=260,
            text_size=14,
            password=True,
            can_reveal_password=True,
        )
        col = Row(
                alignment='center',
                controls=[
                    Card(
                        elevation=15,
                        content=Container(
                            # width=400,
                            # height=400,
                            padding=padding.all(20),
                            gradient=self.GradientGenerator(
                                "#ffffff", "#c6f0f0"
                            ),
                            border_radius=border_radius.all(12),
                            content=Column(
                                horizontal_alignment="center",
                                alignment="start",
                                controls=[
                                    Text(
                                        "Creat Account",
                                        size=20,
                                        weight="w700",
                                        text_align="center",
                                    ),
                                    Container(
                                        padding=padding.only(bottom=10)
                                    ),
                                    self.phone_text,
                                    Container(
                                        padding=padding.only(bottom=10)
                                    ),
                                    self.password,
                                    Container(
                                        padding=padding.only(bottom=10)
                                    ),
                                    Row(
                                        alignment="center",
                                        spacing=10,
                                        controls=[
                                            FilledButton(
                                                content=Text(
                                                    "Create acount",
                                                    weight="w700",
                                                ),
                                                width=160,
                                                height=40,
                                                on_click=lambda e: self.register_user(
                                                    e,
                                                    self.phone_text.value,
                                                    self.password.value,
                                                    page
                                                )
                                            ),
                                            self.snack,
                                        ],
                                    ),
                                ],
                            ),
                        ),
                    )
                ],
                )
        return View(
            controls=[
                col,
                bar_item(page)
            ]
        )